def tbc(event, context):
    print("Great Success!")
